import Header from '../../components/Header'
import Footer from '../../components/Footer'
import styles from './Contatos.module.css'

function Contatos() {
  return (
    <>
      <Header />
      <div className={styles.container}>
        <h1>Contatos</h1>
        <p>Entre em contacto connosco através dos canais disponíveis.</p>
      </div>
      <Footer />
    </>
  )
}

export default Contatos
