import Header from '../../components/Header'
import Footer from '../../components/Footer'
import { Link } from 'react-router-dom'
import styles from './Home.module.css'

function Home() {
  return (
    <>
      <Header />
      <div className={styles.container}>
        <h1>Bem-vindo à Página Inicial</h1>
        <p>Esta é a página principal da nossa aplicação desenvolvida em React com rotas.</p>
        <Link to="/sobre" className='btn btn-red'>
          Saiba mais sobre nós!
        </Link>
      </div>
      <Footer />
    </>
  )
}

export default Home
