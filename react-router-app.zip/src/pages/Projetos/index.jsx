import Header from '../../components/Header'
import Footer from '../../components/Footer'
import styles from './Projetos.module.css'

function Projetos() {
  return (
    <>
      <Header />
      <div className={styles.container}>
        <h1>Projetos</h1>
        <p>Estes são alguns dos nossos projetos desenvolvidos.</p>
      </div>
      <Footer />
    </>
  )
}

export default Projetos
