import Header from '../../components/Header'
import Footer from '../../components/Footer'
import styles from './Sobre.module.css'

function Sobre() {
  return (
    <>
      <Header />
      <div className={styles.container}>
        <h1>Sobre</h1>
        <p>Conheça mais sobre a nossa equipa e os nossos objetivos.</p>
      </div>
      <Footer />
    </>
  )
}

export default Sobre
